
import React, { useState } from 'react';
import { Post, PostType } from '../types';
import { PostCard } from '../components/PostCard';
import { Plus, LayoutDashboard, FileUp, ListChecks, CheckCircle2 } from 'lucide-react';

interface DashboardProps {
  user: any;
  posts: Post[];
  onAddPost: (post: Post) => void;
  onDeletePost: (id: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ user, posts, onAddPost, onDeletePost }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    type: 'photo' as PostType,
    category: 'News' as Post['category'],
    contentUrl: '',
    fileName: ''
  });

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFormData(prev => ({ ...prev, fileName: file.name }));

    const reader = new FileReader();
    reader.onloadend = () => {
      setFormData(prev => ({ ...prev, contentUrl: reader.result as string }));
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newPost: Post = {
      id: Date.now().toString(),
      author: user.name,
      createdAt: new Date().toISOString(),
      ...formData
    };
    onAddPost(newPost);
    setIsAdding(false);
    setFormData({
      title: '',
      description: '',
      type: 'photo',
      category: 'News',
      contentUrl: '',
      fileName: ''
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div>
          <h1 className="text-3xl font-black text-slate-900 mb-1">Welcome, {user.name}</h1>
          <p className="text-slate-500 flex items-center space-x-2">
            <CheckCircle2 size={16} className="text-emerald-500" />
            <span>Administrator Control Panel</span>
          </p>
        </div>
        <button 
          onClick={() => setIsAdding(!isAdding)}
          className={`flex items-center space-x-2 px-6 py-3 rounded-2xl font-bold transition-all ${
            isAdding ? 'bg-slate-200 text-slate-600' : 'bg-slate-900 text-white shadow-lg shadow-slate-900/20'
          }`}
        >
          <Plus size={20} />
          <span>{isAdding ? 'Cancel Post' : 'Create New Content'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Sidebar Stats */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Quick Stats</h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-slate-600 text-sm">Total Posts</span>
                <span className="text-slate-900 font-bold">{posts.length}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-600 text-sm">News Items</span>
                <span className="text-slate-900 font-bold">{posts.filter(p => p.category === 'News').length}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-600 text-sm">Project Items</span>
                <span className="text-slate-900 font-bold">{posts.filter(p => p.category === 'Projects').length}</span>
              </div>
            </div>
          </div>

          <div className="bg-blue-600 p-6 rounded-3xl text-white shadow-lg shadow-blue-600/20">
            <LayoutDashboard size={32} className="mb-4 opacity-50" />
            <h3 className="font-bold text-lg mb-2">Editor's Tip</h3>
            <p className="text-blue-100 text-sm leading-relaxed">
              Always add clear descriptions to help our visitors understand the context of Trendline projects.
            </p>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="lg:col-span-3 space-y-8">
          {isAdding && (
            <div className="bg-white p-8 rounded-[2.5rem] shadow-xl border border-slate-100 animate-in fade-in slide-in-from-top-4 duration-500">
              <div className="flex items-center space-x-3 mb-8">
                <div className="bg-slate-100 p-3 rounded-2xl">
                   <FileUp className="text-slate-900" size={24} />
                </div>
                <h2 className="text-2xl font-black text-slate-900">Post New Content</h2>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700">Title</label>
                    <input 
                      required
                      type="text"
                      className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-4 focus:ring-2 focus:ring-slate-900 focus:bg-white outline-none transition-all"
                      placeholder="Catchy headline..."
                      value={formData.title}
                      onChange={e => setFormData({...formData, title: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700">Category</label>
                    <select 
                      className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-4 focus:ring-2 focus:ring-slate-900 focus:bg-white outline-none transition-all"
                      value={formData.category}
                      onChange={e => setFormData({...formData, category: e.target.value as any})}
                    >
                      <option value="Home">Home (Featured)</option>
                      <option value="News">News / Blog</option>
                      <option value="Projects">Projects / Showcase</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Description</label>
                  <textarea 
                    required
                    rows={3}
                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-4 focus:ring-2 focus:ring-slate-900 focus:bg-white outline-none transition-all"
                    placeholder="Tell us more about this content..."
                    value={formData.description}
                    onChange={e => setFormData({...formData, description: e.target.value})}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700">Media Type</label>
                    <div className="flex bg-slate-100 p-1 rounded-2xl">
                      {['photo', 'video', 'document'].map((type) => (
                        <button
                          key={type}
                          type="button"
                          onClick={() => setFormData({...formData, type: type as PostType})}
                          className={`flex-1 py-2 px-3 rounded-xl text-sm font-bold transition-all capitalize ${
                            formData.type === type ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
                          }`}
                        >
                          {type}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700">Content Source</label>
                    <div className="relative">
                      <input 
                        type="file" 
                        id="fileInput"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                      <label 
                        htmlFor="fileInput"
                        className="flex items-center justify-center space-x-2 w-full bg-slate-50 border border-slate-200 border-dashed rounded-2xl p-4 hover:bg-slate-100 cursor-pointer transition-all"
                      >
                        <FileUp size={20} className="text-slate-400" />
                        <span className="text-slate-500 text-sm font-medium">
                          {formData.fileName || 'Select File from Device'}
                        </span>
                      </label>
                    </div>
                  </div>
                </div>

                <button 
                  type="submit"
                  disabled={!formData.contentUrl}
                  className="w-full bg-slate-900 text-white py-5 rounded-[1.5rem] font-bold text-lg hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.98] transition-all"
                >
                  Publish to Trendline
                </button>
              </form>
            </div>
          )}

          <div className="space-y-6">
            <div className="flex items-center space-x-2 mb-2">
               <ListChecks className="text-slate-400" size={20} />
               <h2 className="text-xl font-bold text-slate-900">Manage Content Feed</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {posts.slice().reverse().map(post => (
                <PostCard 
                  key={post.id} 
                  post={post} 
                  isAdmin 
                  onDelete={onDeletePost} 
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
