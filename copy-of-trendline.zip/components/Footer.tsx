
import React from 'react';
import { INSTAGRAM_URL, CREATED_BY, Logo } from '../constants';
import { Instagram } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-white mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex flex-col md:flex-row justify-between items-center space-y-8 md:space-y-0">
          <div className="flex flex-col items-center md:items-start space-y-4">
             <div className="flex items-center bg-white rounded-lg p-2">
               <Logo className="h-8" />
             </div>
             <p className="text-slate-400 text-sm">
               Empowering trends through innovation and collaboration.
             </p>
          </div>

          <div className="flex flex-col items-center space-y-4">
            <h3 className="font-bold text-lg">Follow Us</h3>
            <a 
              href={INSTAGRAM_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-center space-x-2 text-slate-300 hover:text-pink-400 transition-all"
            >
              <Instagram size={20} />
              <span className="font-semibold text-lg border-b border-transparent group-hover:border-pink-400 transition-all">trend_line_us</span>
            </a>
          </div>

          <div className="text-center md:text-right space-y-2">
            <p className="text-slate-400 text-sm">
              &copy; {new Date().getFullYear()} Trendline. All rights reserved.
            </p>
            <p className="text-slate-300 font-medium">
              Created by <span className="text-white border-b border-slate-600">{CREATED_BY}</span>
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};
