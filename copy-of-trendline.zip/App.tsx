
import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Home } from './pages/Home';
import { News } from './pages/News';
import { Projects } from './pages/Projects';
import { About } from './pages/About';
import { Login } from './pages/Login';
import { Dashboard } from './pages/Dashboard';
import { INITIAL_POSTS, SITE_NAME } from './constants';
import { Post } from './types';

const App: React.FC = () => {
  const [posts, setPosts] = useState<Post[]>(() => {
    const saved = localStorage.getItem('trendline_posts');
    return saved ? JSON.parse(saved) : INITIAL_POSTS;
  });

  const [currentUser, setCurrentUser] = useState<any>(() => {
    const saved = localStorage.getItem('trendline_user');
    return saved ? JSON.parse(saved) : null;
  });

  useEffect(() => {
    localStorage.setItem('trendline_posts', JSON.stringify(posts));
  }, [posts]);

  useEffect(() => {
    localStorage.setItem('trendline_user', JSON.stringify(currentUser));
  }, [currentUser]);

  const handleAddPost = (post: Post) => {
    setPosts(prev => [...prev, post]);
  };

  const handleDeletePost = (id: string) => {
    if (confirm('Are you sure you want to delete this content?')) {
      setPosts(prev => prev.filter(p => p.id !== id));
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
  };

  return (
    <Router>
      <div className="min-h-screen flex flex-col selection:bg-slate-900 selection:text-white">
        <Navbar currentUser={currentUser} onLogout={handleLogout} />
        
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home posts={posts} />} />
            <Route path="/news" element={<News posts={posts} />} />
            <Route path="/projects" element={<Projects posts={posts} />} />
            <Route path="/about" element={<About />} />
            <Route 
              path="/login" 
              element={currentUser ? <Navigate to="/admin" /> : <Login onLogin={setCurrentUser} />} 
            />
            <Route 
              path="/admin" 
              element={
                currentUser ? (
                  <Dashboard 
                    user={currentUser} 
                    posts={posts} 
                    onAddPost={handleAddPost} 
                    onDeletePost={handleDeletePost} 
                  />
                ) : (
                  <Navigate to="/login" />
                )
              } 
            />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </main>

        <Footer />
      </div>
    </Router>
  );
};

export default App;
